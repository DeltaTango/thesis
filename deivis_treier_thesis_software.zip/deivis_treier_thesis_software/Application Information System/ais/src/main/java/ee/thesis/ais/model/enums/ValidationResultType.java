package ee.thesis.ais.model.enums;

public enum ValidationResultType {
    VALID,
    INVALID,
    FAILED,
    ERROR
}