package ee.thesis.ais.controller;

import ee.thesis.ais.model.entity.Identity;
import ee.thesis.ais.model.entity.IdentityResult;
import ee.thesis.ais.service.RestService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;

/**
 * This class acts as REST controller for controlling AIS input/output operations
 */
@Controller
public class RestController {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    RestService restService;

    /**
     * REST endpoint for single Identity callback.
     *
     * @param idUuid - Identity UUID
     * @return ResponseEntity<Identity> - Identity type answer and HTTP status code.
     */
    @RequestMapping(method = RequestMethod.GET, value = "/getidentity")
    public ResponseEntity<IdentityResult> getIdentity(
            @RequestParam(value = "identity_uuid", required = true) String idUuid) {
        try {
            IdentityResult identityResult = restService.getIdentity(idUuid);
            if (identityResult == null) {
                new ResponseEntity<IdentityResult>(HttpStatus.INTERNAL_SERVER_ERROR);
            }
            return new ResponseEntity<IdentityResult>(identityResult, HttpStatus.OK);
        } catch (Exception exc) {
            return new ResponseEntity<IdentityResult>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * REST endpoint for single Identity callback.
     *
     * @param payload - String of JSON in payload
     * @return ResponseEntity<Identity> - Identity type answer and HTTP status code.
     */
    @RequestMapping(method = RequestMethod.POST, value = "/postIdentity")
    public ResponseEntity<Identity> putIdentity(@RequestBody String payload,
                                                @RequestHeader(value="History-Id-Uuid", required = false)
                                              String historyIdUuid) {
        try {
            Identity result = restService.postIdentity(historyIdUuid, payload);
            if (result == null) {
                return new ResponseEntity<Identity>(HttpStatus.BAD_REQUEST);
            }
            return new ResponseEntity<Identity>(result, HttpStatus.CREATED);
        } catch (Exception exc) {
            LOG.error("Error in method putIdentity", exc);
            return new ResponseEntity<Identity>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}