package ee.thesis.ais.model.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import ee.thesis.ais.model.enums.ValidationResultType;
import lombok.Data;
import lombok.NonNull;

import java.time.Instant;

@Data
public class SignatureValidationResult {
    @NonNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ", timezone = "GMT+2")
    private Instant addedTime;
    @NonNull
    private ValidationResultType resultType;
    @NonNull
    private String message;

    public SignatureValidationResult(ValidationResultType resultType, String message) {
        this.addedTime = Instant.now();
        this.resultType = resultType;
        this.message = message;
    }
}
