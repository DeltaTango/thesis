package ee.thesis.ais.model.entity;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;

@Data
public class Identity {

    public static final String TABLE_NAME = "main_data";
    public static final String ID_UUID = "id_uuid";
    public static final String HISTORY_ID_UUID = "history_id_uuid";
    public static final String MAIN_DATA = "main_data";
    public static final String FILE = "file";

    @JsonIgnore
    private Long id;
    @NonNull
    private UUID idUuid;
    private UUID historyIdUuid;
    private String mainData;
    private String file;

    public Identity(UUID idUuid,
                    UUID historyIdUuid,
                    String maindData,
                    String file){
        this.idUuid = idUuid;
        this.historyIdUuid = historyIdUuid;
        this.mainData = maindData;
        this.file = file;
    }

    public Identity(Long id,
                    UUID idUuid,
                    UUID historyIdUuid,
                    String maindData,
                    String bdoc){
        this.id = id;
        this.idUuid = idUuid;
        this.historyIdUuid = historyIdUuid;
        this.mainData = maindData;
        this.file = bdoc;
    }
}