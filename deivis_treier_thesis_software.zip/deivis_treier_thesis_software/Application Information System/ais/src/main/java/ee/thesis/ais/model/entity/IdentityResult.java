package ee.thesis.ais.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class IdentityResult {
    private IdentityLight identity;
    private SignatureValidationResult result;
}
