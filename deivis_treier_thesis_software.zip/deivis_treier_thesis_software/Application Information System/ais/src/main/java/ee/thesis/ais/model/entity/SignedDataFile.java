package ee.thesis.ais.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

@Data
@AllArgsConstructor
public class SignedDataFile {

    @NonNull
    private String fileName;
    @NonNull
    private String mimeType;
    @NonNull
    private byte[] fileContent;
}
