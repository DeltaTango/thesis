package ee.thesis.ais.model.mapper;

import ee.thesis.ais.model.entity.Identity;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import static ee.thesis.ais.model.entity.Identity.ID_UUID;
import static ee.thesis.ais.model.entity.Identity.HISTORY_ID_UUID;
import static ee.thesis.ais.model.entity.Identity.MAIN_DATA;
import static ee.thesis.ais.model.entity.Identity.FILE;

@Component
public class IdentityMapper implements RowMapper<Identity> {

    @Override
    public Identity mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        Identity identity = new Identity(resultSet.getLong("id"),
                (UUID) resultSet.getObject(ID_UUID),
                (UUID) resultSet.getObject(HISTORY_ID_UUID),
                resultSet.getString(MAIN_DATA),
                resultSet.getString(FILE));
        return identity;
    }
}