package ee.thesis.ais.service;

import ee.thesis.ais.model.entity.SignedDataFile;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

@Service
public class FileService {
    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    public SignedDataFile createByteArrayFromString(String content, String fileName, String mimeType){
        try {
            byte[] byteContent = content.getBytes(Charset.forName("UTF-8"));
            return new SignedDataFile(fileName, mimeType, byteContent);
        }
        catch (Exception exc) {
            LOG.error("Error in method createByteArrayFromString", exc);
            return null;
        }
    }

    @Deprecated
    public String exctractContent(SignedDataFile dataFile){
        try {
            ByteArrayInputStream byteStream = new ByteArrayInputStream(dataFile.getFileContent());
            return IOUtils.toString(byteStream, StandardCharsets.UTF_8);
        }
        catch (Exception exc) {
            LOG.error("Error in method exctractContent", exc);
            return null;
        }
    }
}
