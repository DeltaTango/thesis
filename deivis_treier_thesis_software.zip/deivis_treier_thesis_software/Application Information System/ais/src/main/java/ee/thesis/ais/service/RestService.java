package ee.thesis.ais.service;

import ee.thesis.ais.model.entity.*;
import ee.thesis.ais.model.enums.ValidationResultType;
import ee.thesis.ais.model.repository.IdentityRepository;
import org.jooq.tools.json.JSONObject;
import org.jooq.tools.json.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class RestService {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    IdentityRepository identityRepository;
    @Inject
    FileService fileService;
    @Inject
    SignatureService signatureService;

    public IdentityResult getIdentity(String idUuidString) {
        try {
            UUID idUuid = UUID.fromString(idUuidString);
            Identity identity = identityRepository.getIdentity(idUuid);
            if (identity == null) {
                SignatureValidationResult result = new SignatureValidationResult(ValidationResultType.FAILED,
                        "Could not validate signature, no identity found from database.");
                return new IdentityResult(null, result);
            }

            JSONParser parser = new JSONParser();
            IdentityLight resultingIdentity = new IdentityLight(identity.getIdUuid(),
                    identity.getHistoryIdUuid(),
                    (JSONObject) parser.parse(identity.getMainData()),
                    identity.getFile());

            /*
            List<SignedDataFile> signedFiles = signatureService.extractContainer(identity.getFile());
            for (SignedDataFile signedFile : signedFiles) {
                if (signedFile.getFileName().equals("data.json")) {
                    String content = fileService.exctractContent(signedFile);
                    LOG.debug(content);
                    identity.setMainData(content);
                }
            }*/

            SignatureValidationResult result = signatureService.validateSignature(identity.getFile());
            return new IdentityResult(resultingIdentity, result);
        } catch (Exception exc) {
            LOG.error("Error in method getIdentity", exc);
            return null;
        }
    }

    public Identity postIdentity(String historyIdUuidString, String mainData) throws java.sql.SQLException {
        try {
            SignedDataFile mainDataFile = fileService.createByteArrayFromString(
                    mainData, "data.json", "application/json");
            if (mainDataFile == null) return null;

            List<SignedDataFile> fileList = new ArrayList<SignedDataFile>();
            fileList.add(mainDataFile);
            if (fileList.size() < 1) {
                LOG.warn("No files to sign!");
                return null;
            }

            String fileWithSignature = signatureService.createSignedFile(fileList);
            if (fileWithSignature == null) return null;

            UUID historyUuid = null;
            if (historyIdUuidString != null) {
                historyUuid = UUID.fromString(historyIdUuidString);
            }

            Identity identity = new Identity(UUID.randomUUID(),
                    historyUuid,
                    mainData,
                    fileWithSignature);

            if (identityRepository.createIdentity(identity) > 0) return identity;
            else return null;
        } catch (Exception exc) {
            LOG.error("Error in method postIdentity", exc);
            return null;
        }
    }
}
