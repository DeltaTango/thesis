package ee.thesis.ais.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;
import org.jooq.tools.json.JSONObject;

import java.util.UUID;

@Data
@AllArgsConstructor
public class IdentityLight {
    @NonNull
    private UUID idUuid;
    private UUID historyIdUuid;
    private JSONObject mainData;
    private String file;
}
