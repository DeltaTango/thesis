package ee.thesis.ais.service;

import ee.thesis.ais.model.entity.*;
import ee.thesis.ais.model.entity.SignatureValidationResult;

import ee.thesis.ais.model.enums.ValidationResultType;
import org.apache.commons.io.IOUtils;
import org.digidoc4j.*;
import org.digidoc4j.Configuration.Mode;
import org.digidoc4j.exceptions.DigiDoc4JException;
import org.digidoc4j.signers.PKCS11SignatureToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import static org.digidoc4j.ContainerBuilder.BDOC_CONTAINER_TYPE;
import static org.digidoc4j.SignatureProfile.LT;

@Service
public class SignatureService {

    @Value("${signature.pkcs11ModulePath}")
    private String pkcs11ModulePath;
    @Value("${signature.pkcs11ModulePasword}")
    private String pkcs11ModulePasword;
    @Value("${signature.slotIndex}")
    private int slotIndex;
    @Value("${signature.tslLocation}")
    private String tslLocation;
    @Value("${digidoc4j.mode}")
    private String digidoc4jMode;
    @Value("${digidoc4j.ocspSource}")
    private String ocspSource;
    @Value("${digidoc4j.tsaSource}")
    private String tsaSource;
    @Value("${digidoc4j.sslKeystorePath}")
    private String sslKeystorePath;
    @Value("${digidoc4j.validationPolicy}")
    private String validationPolicy;
    @Value("${digidoc4j.connectionTimeout}")
    private int connectionTimeout;
    @Value("${digidoc4j.socketTimeout}")
    private int socketTimeout;

    private Mode mode;

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @PostConstruct
    private void init() {
        if (digidoc4jMode.equals("PROD")) {
            mode = Mode.PROD;
        } else {
            mode = Mode.TEST;
        }
    }

    public String createSignedFile(List<SignedDataFile> fileToSignList) {
        try {
            Configuration configuration = configure(mode);

            List<DataFile> dataFileList = new ArrayList<DataFile>();
            for (SignedDataFile fileToSign : fileToSignList) {
                DataFile dataFile = createDataFile(fileToSign.getFileContent(),
                        fileToSign.getFileName(), fileToSign.getMimeType());
                dataFileList.add(dataFile);
            }

            Container container = createContainer(dataFileList, configuration);

            // During development don't create signatures
            if (!digidoc4jMode.equals("DEV")) {
                LOG.debug("ConnectionTimeOut: " + configuration.getConnectionTimeout());
                Signature signature = createSignature(container);
                container.addSignature(signature);
            }

            return signedFileToBase64String(container.saveAsStream());
        } catch (Exception exc) {
            LOG.error("Error in method createSignedFile", exc);
            return null;
        }
    }

    public SignatureValidationResult validateSignature(String file) {
        try {
            Configuration configuration = configure(mode);
            Container container = createContainer(file, configuration);
            SignatureValidationResult result = validateContainer(container);
            return result;
        } catch (Exception exc) {
            LOG.error("Error in method validateSignature", exc);
            return new SignatureValidationResult(ValidationResultType.ERROR, "Error during signature validation");
        }
    }

    private DataFile createDataFile(byte[] data, String fileName, String mimeType) {
        DataFile dataFile = new DataFile(data, fileName, mimeType);
        return dataFile;
    }

    private Configuration configure(Mode mode) {
        LOG.debug("Configured digidoc4j mode: " + mode.toString());
        Configuration configuration = new Configuration(mode);
        configuration.setConnectionTimeout(connectionTimeout);
        configuration.setSocketTimeout(socketTimeout);
        configuration.setTspSource(tsaSource);
        configuration.setTrustedTerritories("EE");
        configuration.storeDataFilesOnlyInMemory();
        configuration.setSslKeystorePath(sslKeystorePath);
        configuration.setValidationPolicy(validationPolicy);
        if (mode == Mode.TEST) {
            configuration.setTslLocation(tslLocation);
        }
        return configuration;
    }

    private Container createContainer(List<DataFile> dataFileList, Configuration configuration) {
        Container container = ContainerBuilder.
                aContainer(BDOC_CONTAINER_TYPE).
                withConfiguration(configuration). // Configuration settings
                build();

        for (DataFile dataFile : dataFileList) {
            container.addDataFile(dataFile);
        }
        return container;
    }

    private Container createContainer(String file, Configuration configuration) {
        byte[] fileAsByes = Base64.getDecoder().decode(file);
        InputStream stream = new ByteArrayInputStream(fileAsByes);
        Container container = ContainerBuilder.
                aContainer().
                fromStream(stream).
                build();
        return container;
    }

    private PKCS11SignatureToken getSignatureToken() {
        PKCS11SignatureToken signatureToken = new PKCS11SignatureToken(
                pkcs11ModulePath, pkcs11ModulePasword.toCharArray(), slotIndex);
        return signatureToken;
    }

    private Signature createSignature(Container container) {
        Signature signature = SignatureBuilder.
                aSignature(container).
                withSignatureProfile(LT).
                withSignatureToken(getSignatureToken()).
                withSignatureDigestAlgorithm(DigestAlgorithm.SHA512).
                invokeSigning();
        return signature;
    }

    private String signedFileToBase64String(InputStream stream) throws IOException {
        byte[] bytes = IOUtils.toByteArray(stream);
        return Base64.getEncoder().encodeToString(bytes);
    }

    private SignatureValidationResult validateContainer(Container container) {
        ValidationResult result = container.validate();
        if (!result.isValid()) {
            List<DigiDoc4JException> validationErrors = result.getErrors();
            List<DigiDoc4JException> validationWarnings = result.getWarnings();
            List<DigiDoc4JException> containerErrors = result.getContainerErrors();
            String validationReport = result.getReport();
            return new SignatureValidationResult(ValidationResultType.INVALID, validationReport);
        }
        return new SignatureValidationResult(ValidationResultType.VALID, "Signature is valid");
    }

    @Deprecated
    public List<SignedDataFile> extractContainer(String fileBase64Content) {
        List<SignedDataFile> fileList = null;
        Configuration configuration = configure(mode);
        byte[] byteContent = fileBase64Content.getBytes(Charset.forName("UTF-8"));
        InputStream stream = new ByteArrayInputStream(byteContent);
        Container container = ContainerOpener.open(stream, configuration);
        List<DataFile> files = container.getDataFiles();

        for (DataFile dataFile : files) {
            byte[] content = dataFile.getBytes();
            String fileName = dataFile.getName();
            String mimeType = dataFile.getMediaType();
            SignedDataFile signedFile = new SignedDataFile(fileName, mimeType, content);
            fileList.add(signedFile);
        }

        return fileList;
    }
}
