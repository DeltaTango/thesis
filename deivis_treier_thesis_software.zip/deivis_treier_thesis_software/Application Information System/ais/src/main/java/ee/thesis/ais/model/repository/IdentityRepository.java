package ee.thesis.ais.model.repository;

import ee.thesis.ais.model.entity.Identity;
import ee.thesis.ais.model.mapper.IdentityMapper;
import org.postgresql.util.PGobject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.stereotype.Repository;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import javax.inject.Inject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import static ee.thesis.ais.model.entity.Identity.ID_UUID;
import static ee.thesis.ais.model.entity.Identity.TABLE_NAME;
import static java.lang.String.format;

@Repository
public class IdentityRepository {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    IdentityMapper identityMapper;

    @Autowired
    @Qualifier("aisJdbcTemplate")
    private JdbcTemplate aisJdbcTemplate;

    protected static final String INSERT_SQL;

    static {
        //@formatter:off
        INSERT_SQL = format(
                "INSERT INTO %s(%s, %s, %s, %s) VALUES (?, ?, ?, ?)",
                TABLE_NAME,
                ID_UUID,
                Identity.HISTORY_ID_UUID,
                Identity.MAIN_DATA,
                Identity.FILE);
        //@formatter:on
    }

    public List<Identity> getIdentities(UUID historyIdUuid) {
        Object queryObject = new Object[]{historyIdUuid, historyIdUuid};

        String queryString = format("SELECT * FROM %s WHERE %s=? OR %s=? ORDER BY id DESC;",
                TABLE_NAME, Identity.HISTORY_ID_UUID, ID_UUID);

        LOG.info("historyIdUuid: " + historyIdUuid.toString());


        return aisJdbcTemplate.query(queryString, identityMapper, queryObject);
    }

    public Identity getIdentityVersion() {
        String queryString = format("SELECT * FROM %s;", TABLE_NAME);
        return aisJdbcTemplate.queryForObject(queryString, identityMapper);
    }

    public Identity getIdentity(UUID idUuid) {
        try {
            LOG.debug("idUuid: " + idUuid.toString());
            if (idUuid == null) throw new Exception("UUID is null exception");
            String queryString = format("SELECT * FROM %s WHERE %s=? LIMIT 1;", TABLE_NAME, ID_UUID);
            List<Identity> identityList = aisJdbcTemplate.query(
                    new PreparedStatementCreator() {
                        @SuppressFBWarnings("OBL_UNSATISFIED_OBLIGATION_EXCEPTION_EDGE")
                        public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
                            PreparedStatement preparedStatement = connection.prepareStatement(queryString);
                            preparedStatement.setObject(1, idUuid);
                            return preparedStatement;
                        }
                    }, identityMapper);

            if (identityList.size() == 0) {
                return null;
            }
            Identity identity = identityList.get(0);
            return identity;
        } catch (Exception exc) {
            LOG.error("Error in method getIdentity", exc);
            return null;
        }
    }

    @SuppressFBWarnings("OBL_UNSATISFIED_OBLIGATION_EXCEPTION_EDGE")
    public Integer createIdentity(Identity identity) throws java.sql.SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            PGobject jsonObjectMainData = new PGobject();
            jsonObjectMainData.setType("jsonb");
            jsonObjectMainData.setValue(identity.getMainData());

            connection = aisJdbcTemplate.getDataSource().getConnection();
            preparedStatement = connection.prepareStatement(INSERT_SQL);

            int index = 1;
            preparedStatement.setObject(index++, identity.getIdUuid());
            preparedStatement.setObject(index++, identity.getHistoryIdUuid());
            preparedStatement.setObject(index++, jsonObjectMainData);
            preparedStatement.setObject(index, identity.getFile());

            Integer rowsUpdated = preparedStatement.executeUpdate();
            return rowsUpdated;
        } catch (Exception exc) {
            LOG.error("Error in method createIdentity", exc);
            return -1;
        } finally {
            if (connection != null) {
                connection.close();
            }
            if (preparedStatement != null) {
                preparedStatement.close();
            }
        }
    }
}
