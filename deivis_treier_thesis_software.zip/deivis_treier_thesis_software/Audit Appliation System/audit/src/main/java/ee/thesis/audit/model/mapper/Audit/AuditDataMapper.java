package ee.thesis.audit.model.mapper.Audit;

import ee.thesis.audit.model.entity.AuditDatabase.AuditData;
import org.springframework.stereotype.Component;

import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

@Component
public class AuditDataMapper implements RowMapper<AuditData> {

    @Override
    public AuditData mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        AuditData auditData = new AuditData();

        auditData.setId(resultSet.getLong(AuditData.ID_COLUMN));
        auditData.setAddedTime(resultSet.getTimestamp(AuditData.ADDED_COLUMN));
        auditData.setLogDate(resultSet.getTimestamp(AuditData.LOG_DATE_COLUMN));
        auditData.setDbId(resultSet.getString(AuditData.DB_ID_COLUMN).trim());
        auditData.setIdUuid((UUID) resultSet.getObject(AuditData.ID_UUID_COLUMN));
        auditData.setLastHash(resultSet.getString(AuditData.LAST_HASH_COLUMN));
        auditData.setNewHash(resultSet.getString(AuditData.NEW_HASH_COLUMN));
        return auditData;
    }
}
