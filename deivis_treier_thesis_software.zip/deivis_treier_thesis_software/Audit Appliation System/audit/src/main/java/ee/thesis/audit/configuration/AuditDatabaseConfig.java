package ee.thesis.audit.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
public class AuditDatabaseConfig {

    @Bean(name = "H2db")
    @Primary
    @ConfigurationProperties(prefix = "db.audit")
    public DataSource auditDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "auditJdbcTemplate")
    @Primary
    public JdbcTemplate auditJdbcTemplate(@Qualifier("H2db") DataSource auditDataSource) {
        return new JdbcTemplate(auditDataSource);
    }

    @Bean(name = "pgDb")
    @ConfigurationProperties(prefix = "db.ais")
    public DataSource aisDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "aisJdbcTemplate")
    public JdbcTemplate aisJdbcTemplate(@Qualifier("pgDb") DataSource aisDataSource) {
        return new JdbcTemplate(aisDataSource);
    }
}