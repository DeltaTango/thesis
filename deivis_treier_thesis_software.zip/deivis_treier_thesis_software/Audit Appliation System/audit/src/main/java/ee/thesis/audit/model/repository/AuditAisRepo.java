package ee.thesis.audit.model.repository;

import ee.thesis.audit.model.mapper.Ais.HashUsingLimitAndOffsetMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.inject.Inject;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Arrays;


@Repository
public class AuditAisRepo {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    HashUsingLimitAndOffsetMapper hashUsingLimitAndOffsetMapper;

    @Autowired
    @Qualifier("aisJdbcTemplate")
    private JdbcTemplate aisJdbcTemplate;

    public String getTableFullHash(String initialHash, String tableName) {
        try {
            String callSQL = "{ ? = call getTableHashFunctionPublic(?, ?) }";

            Connection connection = aisJdbcTemplate.getDataSource().getConnection();

            CallableStatement statement = connection.prepareCall(callSQL);
            statement.registerOutParameter(1, Types.VARCHAR);
            statement.setString(2, initialHash);
            statement.setString(3, tableName);
            statement.execute();
            String result = statement.getString(1);
            statement.close();
            connection.close();

            String tat = "tat";
            tat = tat.toUpperCase();

            return result;
        } catch (Exception exc) {
            LOG.error("Error in method getTableFullHash:", exc);
            return null;
        }
    }

    public String getTablePartialHash(int startId, int endId, String initialHash, String tableName) {
        try {
            String callSQL = "{ ? = call getPartialTableHashFunctionPublic(?, ?, ?, ?) }";

            Connection connection = aisJdbcTemplate.getDataSource().getConnection();

            CallableStatement statement = connection.prepareCall(callSQL);
            statement.registerOutParameter(1, Types.VARCHAR);
            statement.setInt(2, startId);
            statement.setInt(3, endId);
            statement.setString(4, initialHash);
            statement.setString(5, tableName);
            statement.execute();
            String result = statement.getString(1);
            statement.close();
            connection.close();

            return result;
        } catch (Exception exc) {
            LOG.error("Error in method getTablePartialHash:", exc);
            return null;
        }
    }

    public String getTableErrorDetection(int startId, int endId, String initialHash, String tableName) {
        try {
            String callSQL = "{ ? = call getPartialTableHashFunctionWithErrorDetectionPublic(?, ?, ?, ?) }";

            Connection connection = aisJdbcTemplate.getDataSource().getConnection();

            CallableStatement statement = connection.prepareCall(callSQL);
            statement.registerOutParameter(1, Types.VARCHAR);
            statement.setInt(2, startId);
            statement.setInt(3, endId);
            statement.setString(4, initialHash);
            statement.setString(5, tableName);
            statement.execute();
            String result = statement.getString(1);
            statement.close();
            connection.close();

            return result;
        } catch (Exception exc) {
            LOG.error("Error in method getTableErrorDetection:", exc);
            return null;
        }
    }

}