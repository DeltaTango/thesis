package ee.thesis.audit.model.entity.AuditDatabase;

import lombok.Data;

/* Data class what defines table in H2 databas what
* consists of data about aduitable tables in AIS database */
@Data
public class AuditableTable {

    public static final String TABLE_NAME = "AUDIT.AUDITABLE_TABLES";
    public static final String TABLE_NAME_COLUMN = "TABLE_NAME";
    public static final String INITIAL_HASH_COLUMN = "INITIAL_HASH";

    private String tableName;
    private String initialHash;

    public String getAllAsString(){
        return String.format("AuditableTable: %s|%s", tableName, initialHash);
    }
}
