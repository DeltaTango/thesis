package ee.thesis.audit.model.mapper.Audit;

import ee.thesis.audit.model.entity.AuditDatabase.Table;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static ee.thesis.audit.model.entity.AuditDatabase.Table.*;

/* Component class what maps H2 database INFORMATION_CHEMA to entity object Table*/
@Component
public class TableMapper implements RowMapper<Table> {

    @Override
    public Table mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        Table table = new Table();
        table.setTableName(resultSet.getString(TABLE_NAME_COLLUMN));
        return table;
    }
}