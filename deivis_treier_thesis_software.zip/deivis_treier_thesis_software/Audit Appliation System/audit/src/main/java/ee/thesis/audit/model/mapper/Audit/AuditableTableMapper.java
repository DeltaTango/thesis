package ee.thesis.audit.model.mapper.Audit;

import ee.thesis.audit.model.entity.AuditDatabase.AuditableTable;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import static ee.thesis.audit.model.entity.AuditDatabase.AuditableTable.TABLE_NAME_COLUMN;
import static ee.thesis.audit.model.entity.AuditDatabase.AuditableTable.INITIAL_HASH_COLUMN;

/* Component class that maps jdbc result rows to AuditableTable entity object */
@Component
public class AuditableTableMapper implements RowMapper<AuditableTable> {

    @Override
    public AuditableTable mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        AuditableTable auditableTable = new AuditableTable();
        auditableTable.setTableName(resultSet.getString(TABLE_NAME_COLUMN));
        auditableTable.setInitialHash(resultSet.getString(INITIAL_HASH_COLUMN));
        return auditableTable;
    }
}