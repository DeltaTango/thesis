package ee.thesis.audit.model.repository;

import ee.thesis.audit.model.entity.AuditDatabase.AuditData;
import ee.thesis.audit.model.entity.AuditDatabase.AuditableTable;
import ee.thesis.audit.model.entity.AuditDatabase.Table;
import ee.thesis.audit.model.entity.AuditDatabase.ValidationResult;
import ee.thesis.audit.model.mapper.Audit.AuditDataMapper;
import ee.thesis.audit.model.mapper.Audit.AuditableTableMapper;
import ee.thesis.audit.model.mapper.Audit.TableMapper;
import ee.thesis.audit.model.mapper.Audit.ValidationResultMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import edu.umd.cs.findbugs.annotations.SuppressFBWarnings;

import javax.inject.Inject;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import static java.lang.String.format;

@Repository
public class AuditDatabaseRepo {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    AuditDataMapper auditDataMapper;

    @Autowired
    @Qualifier("auditJdbcTemplate")
    private JdbcTemplate auditJdbcTemplate;

    public AuditData getAuditLogDataByDbId(String tableName, int dbId) {
        try {
            final String queryString = format("SELECT * FROM AUDITDATA.%s WHERE %s=?",
                    tableName,
                    AuditData.DB_ID_COLUMN
            );

            Object[] params = new Object[]{dbId};
            List<AuditData> auditDataList = auditJdbcTemplate.query(queryString, params, new AuditDataMapper());

            if (auditDataList.size() > 0) {
                LOG.debug(auditDataList.get(0).getAllAsString());
                return auditDataList.get(0);
            } else {
                return null;
            }
        } catch (Exception exc) {
            LOG.error("Error in method getAuditLogDataByDbId ", exc);
            return null;
        }
    }

    public AuditData getLastAuditLogData(String tableName) {
        try {
            final String queryString = format("SELECT TOP 1 * FROM AUDITDATA.%s ORDER BY %s DESC;",
                    tableName,
                    AuditData.ADDED_COLUMN);

            List<AuditData> auditDataList = auditJdbcTemplate.query(queryString, new AuditDataMapper());

            if (auditDataList.size() > 0) {
                LOG.debug(auditDataList.get(0).getAllAsString());
                return auditDataList.get(0);
            } else {
                return null;
            }
        } catch (Exception exc) {
            LOG.error("Error in method getLastAuditLogData", exc);
            return null;
        }
    }

    public List<ValidationResult> getValidationResultByTableName(String tableName) {

        final String queryString = String.format("SELECT * FROM AUDIT.%s WHERE %s=?;",
                ValidationResult.TABLE_NAME,
                ValidationResult.TABLE_NAME_COLUMN);

        Object[] params = new Object[]{tableName};
        int[] types = new int[]{Types.CHAR};
        List<ValidationResult> validationResultList = auditJdbcTemplate.query(queryString, params, types,
                new ValidationResultMapper());

        if (validationResultList.size() > 0) {
            LOG.debug(String.format("validationResultList[0] id: %s", validationResultList.get(0).getId()));
            return validationResultList;
        } else {
            return null;
        }
    }

    public AuditableTable getAuditableTableWithTableName(String tableName) {
        try {
            String queryString = String.format("SELECT * FROM %s WHERE %s=?;",
                    AuditableTable.TABLE_NAME,
                    AuditableTable.TABLE_NAME_COLUMN);

            Object[] params = new Object[]{tableName};
            int[] types = new int[]{Types.CHAR};
            List<AuditableTable> auditableTablesList = auditJdbcTemplate.query(
                    queryString, params, types, new AuditableTableMapper());

            return auditableTablesList.get(0);
        } catch (Exception exc) {
            LOG.error("Error in method getAuditableTableWithTableName", exc);
            return null;
        }
    }

    // Method to add new validation results into H2 database AUDIT schema
    @SuppressFBWarnings("OBL_UNSATISFIED_OBLIGATION_EXCEPTION_EDGE")
    public Integer addAuditDataValidationResult(ValidationResult validationResult) {
        try {
            String insertSql = String.format(
                    "INSERT INTO AUDIT.%s (%s, %s, %s, %s) VALUES (?, ?, ?, ?);",
                    ValidationResult.TABLE_NAME,
                    ValidationResult.ADDED_TIME_COLUMN,
                    ValidationResult.RESULT_TYPE_COLUMN,
                    ValidationResult.TABLE_NAME_COLUMN,
                    ValidationResult.MESSAGE_COLUMN
            );

            Connection connection = auditJdbcTemplate.getDataSource().getConnection();
            PreparedStatement preparedStatement = connection.prepareStatement(insertSql);

            int index = 1;
            preparedStatement.setTimestamp(index++, validationResult.getAddedTime());
            preparedStatement.setString(index++, validationResult.getResultType().toString());
            preparedStatement.setString(index++, validationResult.getResultTableName());
            preparedStatement.setString(index++, validationResult.getMessage());

            Integer rowsUpdated = preparedStatement.executeUpdate();
            preparedStatement.close();
            connection.close();

            LOG.debug(String.format("Inserted %s rows into table", rowsUpdated));

            return rowsUpdated;

        } catch (Exception exc) {
            LOG.error("Exception inf method addAuditDataValidationResult." , exc);
            return 0;
        }
    }
}
