package ee.thesis.audit.service;

import ee.thesis.audit.model.entity.AuditDatabase.ValidationResult;
import ee.thesis.audit.model.repository.AuditDatabaseRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Service
public class AuditDatabase {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");

    @Inject
    AuditDatabaseRepo auditDatabaseRepo;

    public List<ValidationResult> getValidationResultsByTableName(String tableName) {
        try{
            return auditDatabaseRepo.getValidationResultByTableName(tableName);
        }
        catch (Exception exc){
            LOG.error("Mehtod getValidationResultsByTableName failed with error", exc);
            return new ArrayList<ValidationResult>();
        }
    }

    //@Scheduled(fixedRate = 15000)
    public void reportCurrentTime() {
        auditDatabaseRepo.getLastAuditLogData("MAIN_DATA");
    }
}
