package ee.thesis.audit.controller;

import ee.thesis.audit.model.entity.AuditDatabase.Table;
import ee.thesis.audit.model.entity.AuditDatabase.ValidationResult;
import ee.thesis.audit.service.AuditActions;
import ee.thesis.audit.service.AuditDatabase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.inject.Inject;
import java.util.Collections;
import java.util.List;

import static ee.thesis.audit.model.enums.ValidationResultType.*;

/**
 * This class acts as REST controller for controlling Audit application input/output operations
 */
@Controller
public class RestController {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    AuditActions auditActions;
    @Inject
    AuditDatabase auditDatabase;

    /**
     * REST endpoint for performing full database check for table
     *
     * @param tableName - Table name to validate
     * @return ResponseEntity<AuditResult> - Identity type answer and HTTP status code.
     */
    @RequestMapping(method = RequestMethod.GET, value = "/validation/full")
    public ResponseEntity<ValidationResult> performFullForTable(
            @RequestParam(value = "table_name", required = true) String tableName) {
        try {
            ValidationResult result = auditActions.performTableFullValidation(tableName);
            return new ResponseEntity<ValidationResult>(result, HttpStatus.OK);
        } catch (Exception exc) {
            LOG.error("Exception in method performFullTable", exc);
            ValidationResult result = new ValidationResult(
                    FAILED,
                    tableName,
                    "Failed due to internal Error");
            return new ResponseEntity<ValidationResult>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * REST endpoint for performing partial database check for table
     *
     * @param tableName   - Table name to validate
     * @param initialHash - Table name to validate
     * @param firstId     - Table name to validate
     * @param lastId      - Table name to validate
     * @return ResponseEntity<AuditResult> - Identity type answer and HTTP status code.
     */
    @RequestMapping(method = RequestMethod.GET, value = "/validation/partial")
    public ResponseEntity<ValidationResult> performPartialForTable(
            @RequestParam(value = "tableName", required = true) String tableName,
            @RequestParam(value = "firstId", required = true) int firstId,
            @RequestParam(value = "lastId", required = true) int lastId,
            @RequestParam(value = "initialHash", required = true) String initialHash
    ) {
        try {
            ValidationResult result = auditActions.performTablePartialValidation(initialHash,
                    firstId, lastId, tableName);
            return new ResponseEntity<ValidationResult>(result, HttpStatus.OK);
        } catch (Exception exc) {
            LOG.error("Error in method performPartialForTable", exc);
            ValidationResult result = new ValidationResult(
                    FAILED,
                    tableName,
                    "Failed due to internal Error");
            return new ResponseEntity<ValidationResult>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * REST endpoint for performing partial database check for table
     *
     * @param tableName   - Table name to validate
     * @param initialHash - Table name to validate
     * @param firstId     - Table name to validate
     * @param lastId      - Table name to validate
     * @return ResponseEntity<AuditResult> - Identity type answer and HTTP status code.
     */
    @RequestMapping(method = RequestMethod.GET, value = "/validation/errorDetection")
    public ResponseEntity<ValidationResult> performErrorDetection(
            @RequestParam(value = "tableName", required = true) String tableName,
            @RequestParam(value = "firstId", required = true) int firstId,
            @RequestParam(value = "lastId", required = true) int lastId,
            @RequestParam(value = "initialHash", required = true) String initialHash
    ) {
        try {
            ValidationResult result = auditActions.performTableErrorDetection(initialHash,
                    firstId, lastId, tableName);
            return new ResponseEntity<ValidationResult>(result, HttpStatus.OK);
        } catch (Exception exc) {
            LOG.error("Error in method performPartialForTable", exc);
            ValidationResult result = new ValidationResult(
                    FAILED,
                    tableName,
                    "Failed due to internal Error");
            return new ResponseEntity<ValidationResult>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * REST endpoint for listing all validation results filtered by table name
     *
     * @param tableName - Table name to validate
     * @return ResponseEntity<List<AuditResult>> - Identity type answer and HTTP status code.
     */
    @RequestMapping(method = RequestMethod.GET, value = "/result/listByTableName")
    public ResponseEntity<List<ValidationResult>> getResultsbyTable(
            @RequestParam(value = "table_name", required = true) String tableName) {
        try {
            List<ValidationResult> resultList = auditDatabase.getValidationResultsByTableName(tableName);
            return new ResponseEntity<List<ValidationResult>>(resultList, HttpStatus.OK);
        } catch (Exception exc) {
            LOG.error("Error in method getResultsbyTable", exc);
            List<ValidationResult> result = Collections.singletonList(new ValidationResult(
                    FAILED,
                    tableName,
                    "Failed due to internal Error"));
            return new ResponseEntity<List<ValidationResult>>(result, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}