package ee.thesis.audit.model.enums;

public enum ValidationResultType {
    VALID,
    INVALID,
    FAILED,
    ERROR
}