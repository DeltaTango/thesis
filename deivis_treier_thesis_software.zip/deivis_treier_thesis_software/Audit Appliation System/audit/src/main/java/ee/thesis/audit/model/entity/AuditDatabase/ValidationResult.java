package ee.thesis.audit.model.entity.AuditDatabase;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import ee.thesis.audit.model.enums.ValidationResultType;
import lombok.Data;
import lombok.NonNull;

import java.sql.Timestamp;
import java.util.Calendar;

@Data
public class ValidationResult {
    public static final String TABLE_NAME = "VALIDATION_RESULT";
    public static final String ID_COLUMN = "ID";
    public static final String ADDED_TIME_COLUMN = "ADDED_TIME";
    public static final String RESULT_TYPE_COLUMN = "RESULT_TYPE";
    public static final String TABLE_NAME_COLUMN = "TABLE_NAME";
    public static final String MESSAGE_COLUMN = "MESSAGE";

    @JsonIgnore
    private Long id;
    @NonNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ", timezone = "GMT+2")
    private Timestamp addedTime;
    @NonNull
    private ValidationResultType resultType;
    @NonNull
    private String resultTableName;
    @NonNull
    private String message;

    public ValidationResult(ValidationResultType resultType,
                            String resultTableName,
                            String message) {
        this.addedTime = new Timestamp(Calendar.getInstance().getTime().getTime());
        this.resultType = resultType;
        this.resultTableName = resultTableName;
        this.message = message;
    }

    public ValidationResult(Long id,
                            Timestamp addedTime,
                            ValidationResultType resultType,
                            String resultTableName,
                            String message) {
        this.id = id;
        this.addedTime = addedTime;
        this.resultType = resultType;
        this.resultTableName = resultTableName;
        this.message = message;
    }
}
