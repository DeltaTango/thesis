package ee.thesis.audit.model.entity.AuditDatabase;

import lombok.Data;

/*Data object that represents INFORMATION SCHEMA table TABLES
* It includes data about database tables in H2 database and filled automatically by H2*/
@Data
public class Table {

    public static final String TABLE_NAME = "TABLES";
    public static final String TABLE_NAME_COLLUMN = "TABLE_NAME";

    private String tableName;
}
