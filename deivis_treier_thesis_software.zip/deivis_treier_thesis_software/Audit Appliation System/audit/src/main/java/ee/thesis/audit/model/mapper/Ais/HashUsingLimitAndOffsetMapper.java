package ee.thesis.audit.model.mapper.Ais;

import ee.thesis.audit.model.entity.AisDatabase.HashUsingLimitAndOffset;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

@Component
public class HashUsingLimitAndOffsetMapper implements RowMapper<HashUsingLimitAndOffset> {

    @Override
    public HashUsingLimitAndOffset mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        HashUsingLimitAndOffset retrievedHash = new HashUsingLimitAndOffset();

        retrievedHash.setRetrievedHash(resultSet.getString(HashUsingLimitAndOffset.RETRIEVED_HASH_COLUMN));
        return retrievedHash;
    }
}
