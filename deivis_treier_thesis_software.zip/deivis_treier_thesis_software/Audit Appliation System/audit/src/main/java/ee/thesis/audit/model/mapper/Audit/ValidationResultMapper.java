package ee.thesis.audit.model.mapper.Audit;

import ee.thesis.audit.model.entity.AuditDatabase.ValidationResult;
import ee.thesis.audit.model.enums.ValidationResultType;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

/* Component class what maps H2 databse table AUDIT.VALIDATION_RESULT to ValidationResult object*/
@Component
public class ValidationResultMapper implements RowMapper<ValidationResult> {

    @Override
    public ValidationResult mapRow(ResultSet resultSet, int rowNum) throws SQLException {
        ValidationResult validationResult = new ValidationResult(
                resultSet.getLong(ValidationResult.ID_COLUMN),
                resultSet.getTimestamp(ValidationResult.ADDED_TIME_COLUMN),
                ValidationResultType.valueOf(
                        resultSet.getString(ValidationResult.RESULT_TYPE_COLUMN)),
                resultSet.getString(ValidationResult.TABLE_NAME_COLUMN),
                resultSet.getString(ValidationResult.MESSAGE_COLUMN)
        );
        return validationResult;
    }
}