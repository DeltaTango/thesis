package ee.thesis.audit.service;

import ee.thesis.audit.model.entity.AuditDatabase.AuditData;
import ee.thesis.audit.model.entity.AuditDatabase.AuditableTable;
import ee.thesis.audit.model.entity.AuditDatabase.ValidationResult;
import ee.thesis.audit.model.enums.ValidationResultType;
import ee.thesis.audit.model.repository.AuditAisRepo;
import ee.thesis.audit.model.repository.AuditDatabaseRepo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.inject.Inject;
import java.util.ArrayList;
import java.util.List;

import static java.lang.String.format;

@Service
public class AuditActions {

    protected final Logger LOG = LoggerFactory.getLogger(getClass());

    @Inject
    AuditAisRepo auditAisRepo;
    @Inject
    AuditDatabaseRepo auditDatabaseRepo;

    public ValidationResult performTableFullValidation(String tableName) {
        try {
            AuditableTable table = auditDatabaseRepo.getAuditableTableWithTableName(tableName);
            AuditData auditInfo = auditDatabaseRepo.getLastAuditLogData(tableName);

            if (table != null) {
                if (auditInfo == null) {
                    String message = format("No audit record found for table %s", tableName);
                    LOG.debug(message);
                    ValidationResult result = new ValidationResult(ValidationResultType.FAILED, tableName, message);
                    auditDatabaseRepo.addAuditDataValidationResult(result);
                    return result;
                }

                String hash = auditAisRepo.getTableFullHash(table.getInitialHash(), tableName);
                return performComparison(auditInfo, hash, tableName);
            }
            String message = format("No such table %s", tableName);
            LOG.debug(message);
            ValidationResult result = new ValidationResult(ValidationResultType.FAILED, tableName, message);
            return result;
        } catch (Exception exc) {
            LOG.error("Mehtod performTableFullValidation failed with error", exc);
            return new ValidationResult(ValidationResultType.FAILED, tableName, "Failed due to exception");
        }
    }

    public ValidationResult performTablePartialValidation(String initialHash, int startId,
                                                          int endId, String tableName) {
        try {
            AuditableTable table = auditDatabaseRepo.getAuditableTableWithTableName(tableName);
            AuditData auditInfoFirst = auditDatabaseRepo.getAuditLogDataByDbId(tableName, startId);
            AuditData auditInfoLast = auditDatabaseRepo.getAuditLogDataByDbId(tableName, endId);
            if (table != null) {
                String hash = auditAisRepo.getTablePartialHash(startId, endId, auditInfoFirst.getLastHash(), tableName);
                return performComparison(auditInfoLast, hash, tableName);
            }
            String message = format("No such table %s", tableName);
            LOG.debug(message);
            ValidationResult result = new ValidationResult(ValidationResultType.FAILED, tableName, message);
            return result;
        } catch (Exception exc) {
            LOG.error("Mehtod performTablePartialValidation failed with errorr", exc);
            return new ValidationResult(ValidationResultType.FAILED, tableName, "Failed due to exception");
        }
    }

    public ValidationResult performTableErrorDetection(String initialHash, int startId,
                                                       int endId, String tableName) {
        try {
            AuditableTable table = auditDatabaseRepo.getAuditableTableWithTableName(tableName);
            AuditData auditInfoFirst = auditDatabaseRepo.getAuditLogDataByDbId(tableName, startId);
            AuditData auditInfoLast = auditDatabaseRepo.getAuditLogDataByDbId(tableName, endId);
            if (table != null) {
                String result = auditAisRepo.getTableErrorDetection(startId, endId, auditInfoFirst.getLastHash(), tableName);
                LOG.debug(result);
                String[] resultSplited = result.split("|");

                if (resultSplited.length > 3) {
                    LOG.debug("Result OK: " + result);
                    return performComparison(auditInfoLast, result, tableName);
                } else {
                    LOG.debug("Result NOK, resultSplited.len: " + resultSplited.length);
                    String message = String.format("Failure point id_uuid: %s, error_hahs: %s, last_hash: %s",
                            resultSplited[0], resultSplited[1], resultSplited[2]);
                    return new ValidationResult(ValidationResultType.FAILED, tableName, message);
                }
            }
            String message = format("No such table %s", tableName);
            LOG.debug(message);
            ValidationResult result = new ValidationResult(ValidationResultType.FAILED, tableName, message);
            return result;
        } catch (Exception exc) {
            LOG.error("Error in method performTablePartialValidation", exc);
            return new ValidationResult(ValidationResultType.FAILED, tableName, "Failed due to exception");
        }
    }

    private ValidationResult performComparison(AuditData auditInfoLast, String hash, String tableName) {
        if (hash != null) {
            if (hash.equals(auditInfoLast.getNewHash())) {
                String message = "Hash link is correct";
                LOG.debug(message);
                ValidationResult result = new ValidationResult(ValidationResultType.VALID, tableName, message);
                auditDatabaseRepo.addAuditDataValidationResult(result);
                return result;
            } else {
                String message = format("Hash link is incorrect! Calculated: %s, last known: %s",
                        hash, auditInfoLast.getNewHash());
                LOG.debug(message);
                ValidationResult result = new ValidationResult(ValidationResultType.INVALID, tableName, message);
                auditDatabaseRepo.addAuditDataValidationResult(result);
                return result;
            }
        } else {
            String message = format("AIS database did'nt calculate hash for table %s", tableName);
            LOG.debug(message);
            ValidationResult result = new ValidationResult(ValidationResultType.FAILED, tableName, message);
            auditDatabaseRepo.addAuditDataValidationResult(result);
            return result;
        }
    }

}
