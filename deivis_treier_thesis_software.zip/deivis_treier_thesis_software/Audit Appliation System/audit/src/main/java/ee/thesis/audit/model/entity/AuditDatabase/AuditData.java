package ee.thesis.audit.model.entity.AuditDatabase;

import lombok.Data;

import java.sql.Timestamp;
import java.util.UUID;

@Data
public class AuditData {

    public static final String ID_COLUMN = "ID";
    public static final String ADDED_COLUMN = "ADDED";
    public static final String LOG_DATE_COLUMN = "LOG_DATE";
    public static final String DB_ID_COLUMN = "DB_ID";
    public static final String ID_UUID_COLUMN = "ID_UUID";
    public static final String LAST_HASH_COLUMN = "LAST_HASH";
    public static final String NEW_HASH_COLUMN = "NEW_HASH";

    private Long id;
    private Timestamp addedTime;
    private Timestamp logDate;
    private String dbId;
    private UUID idUuid;
    private String lastHash;
    private String newHash;

    public String getIdUuidString() {
        return idUuid.toString();
    }

    public String getAllAsString(){
        return String.format("AuditData: %s|%s|%s", idUuid, lastHash, newHash);
    }
}
