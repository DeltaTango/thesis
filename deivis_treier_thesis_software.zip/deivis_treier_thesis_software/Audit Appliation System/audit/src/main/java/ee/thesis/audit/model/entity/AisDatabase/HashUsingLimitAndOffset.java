package ee.thesis.audit.model.entity.AisDatabase;

import lombok.Data;

@Data
public class HashUsingLimitAndOffset {
    public static final String RETRIEVED_HASH_COLUMN = "new_hash";

    public String retrievedHash;
}
