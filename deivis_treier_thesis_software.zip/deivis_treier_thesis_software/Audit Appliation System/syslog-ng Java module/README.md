#Build

$ gradle fatJar
