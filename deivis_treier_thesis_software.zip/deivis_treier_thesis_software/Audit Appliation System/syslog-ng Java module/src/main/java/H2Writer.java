import org.syslog_ng.InternalMessageSender;
import org.syslog_ng.TextLogDestination;
import org.syslog_ng.options.*;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.UUID;
import java.util.Calendar;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.time.Instant;

public class H2Writer extends TextLogDestination {

    private static final String CREATE_SCHEMA = "CREATE SCHEMA IF NOT EXISTS AUDITDATA;";

    private static final String CREATE_SQL = "CREATE TABLE IF NOT EXISTS AUDITDATA.MAIN_DATA (id IDENTITY PRIMARY KEY, " +
            "added TIMESTAMP, log_date TIMESTAMP, db_id CHAR, id_uuid UUID, last_hash CHAR, new_hash CHAR);";

    private Connection connection = null;
    String dbConnectionUrl;
    String dbUser;
    String dbPassword;

    public H2Writer(long arg0) {
        super(arg0);
    }

    /* Method what parses audit log message and prepares data to for inserting into database */
    private String[] parseMessage(String message) {
        // YYYY-MM-DDTHH:MM:SS+HH:MM server_name program_name: audit:main_data,1,3c7a7ca9-e35b-4c02-9044-2c0ad849164b,160488245c65a2f36685f107e1f499caac7f37dc6afb65a4ed9cc9f300b30f05,91137cf4412faeba17801750e00c30eb5e64263085fb02128b835049f3b01fab

        // YYYY-MM-DDTHH:MM:SS+HH:MM server_name program_name: <message text>
        message = message.trim(); // remove potential line feed from end of message
        String[] splited = message.split("hashChainAudit:");
        String date = splited[0].split(" ")[0];
        String messageText = splited[1];

        //audit:<table_name>,<id>,<id_uuid>,<last_hash>,<new_hash>
        String[] splitedMessageText = messageText.split(",");
        String[] result = {date,               // DateTime - 0
                splitedMessageText[0].trim(),  // table_name - 1
                splitedMessageText[1].trim(),  // id - 2
                splitedMessageText[2].trim(),  // id_uuid - 3
                splitedMessageText[3].trim(),  // last_hash - 4
                splitedMessageText[4].trim()}; // new_hash - 5
        return result;
    }

    @Override
    protected boolean send(String inputString) {
        try {
            InternalMessageSender.info("Recieved new message");
            String[] parsedMessage = parseMessage(inputString);
            String tableName = parsedMessage[1].toUpperCase();

            String query = String.format("INSERT INTO AUDITDATA.%s (added, log_date, db_id, id_uuid, last_hash, " +
                    "new_hash) VALUES (?,?,?,?,?,?);", tableName);
            PreparedStatement insertStmt = connection.prepareStatement(query);
            Date now = Calendar.getInstance().getTime();
            Timestamp currentTimestamp = new Timestamp(now.getTime());
            insertStmt.setTimestamp(1, currentTimestamp);

            DateTimeFormatter timeFormatter = DateTimeFormatter.ISO_DATE_TIME;
            TemporalAccessor accessor = timeFormatter.parse(parsedMessage[0]);
            Date logDate = Date.from(Instant.from(accessor));
            Timestamp logTimestamp = new Timestamp(logDate.getTime());

            insertStmt.setTimestamp(2, logTimestamp); //yyyy-mm-dd hh:mm:ss[.fffffffff]
            insertStmt.setLong(3, Long.parseLong(parsedMessage[2]));
            insertStmt.setObject(4, UUID.fromString(parsedMessage[3]));
            insertStmt.setString(5, parsedMessage[4]);
            insertStmt.setString(6, parsedMessage[5]);

            int result = 0;
            result = insertStmt.executeUpdate();
            insertStmt.close();

            if (result < 1) {
                InternalMessageSender.error("Unable to insert data to database");
                return false;
            }
            return true;
        } catch (Exception exc) {
            InternalMessageSender.error(exc.getMessage());
            return false;
        }
    }

    @Override
    protected boolean open() {
        try {
            InternalMessageSender.info("Connecting to H2 audit database");
            Class.forName("org.h2.Driver");
            connection = DriverManager.getConnection(dbConnectionUrl, dbUser, dbPassword);
            if (connection == null) {
                InternalMessageSender.error("No connection to aduit database configured");
                return false;
            }
            return initDatabase();
        } catch (Exception exc) {
            InternalMessageSender.error("Unable to connect to H2 database. " + exc.getMessage());
            return false;
        }
    }

    @Override
    protected void close() {
        try {
            this.connection.close();
            connection = null;
            InternalMessageSender.info("Connection to H2 database closed");
        } catch (SQLException exc) {
            InternalMessageSender.error(exc.getMessage());
        }
    }

    @Override
    protected boolean isOpened() {
        if (connection != null) {
            return true;
        }
        return false;
    }

    @Override
    protected String getNameByUniqOptions() {
        return "NOTHING TO GIVE";
    }

    @Override
    protected boolean init() {

        Options requiredOptions = new Options();
        requiredOptions.put(new RequiredOptionDecorator(new StringOption(this, "dbConnectionUrl")));
        requiredOptions.put(new RequiredOptionDecorator(new StringOption(this, "dbUser")));
        requiredOptions.put(new RequiredOptionDecorator(new StringOption(this, "dbPassword")));

        try {
            requiredOptions.validate();
        } catch (InvalidOptionException e) {
            InternalMessageSender.error("Some options are missing");
            return false;
        }

        dbConnectionUrl = getOption("dbConnectionUrl");
        dbUser = getOption("dbUser");
        dbPassword = getOption("dbPassword");

        return true;
    }

    private boolean initDatabase() throws SQLException {

        InternalMessageSender.info("Initializing database");
        PreparedStatement createSchemaPreparedStatement = connection.prepareStatement(CREATE_SCHEMA);
        createSchemaPreparedStatement.executeUpdate();
        createSchemaPreparedStatement.close();

        PreparedStatement createPreparedStatement = connection.prepareStatement(CREATE_SQL);
        createPreparedStatement.executeUpdate();
        createPreparedStatement.close();
        return true;
    }

    @Override
    protected void deinit() {
        // Here we should alert syslog about deiniting java module
    }
}
