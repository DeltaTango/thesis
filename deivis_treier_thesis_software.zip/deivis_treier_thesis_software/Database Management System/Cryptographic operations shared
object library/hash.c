#include <string.h>
#include <syslog.h>
#include <openssl/sha.h>
#include <postgres.h>
#include <executor/spi.h>
#include <utils/rel.h>
#include <utils/builtins.h>
#include "hash.h"

static const char hexdigits[16] = "0123456789abcdef";

char *dup_pgtext(text *what)
{
    size_t len = VARSIZE(what)-VARHDRSZ;
    char *dup = palloc(len+1);
    memcpy(dup, VARDATA(what), len);
    dup[len] = 0;
    return dup;
}

/**
 * @returns varchar with calculated row hash
 * @note Postgre server takes care of freeing allocated memory
 * @note elog statements seem to have significant performance impact
 */
PG_FUNCTION_INFO_V1(getTableHashFunction);
Datum getTableHashFunction(PG_FUNCTION_ARGS)
{
    text *initial_hash_text, *table_name_text;
    int limit_value = 100;

    initial_hash_text = PG_GETARG_TEXT_P(0);
    table_name_text = PG_GETARG_TEXT_P(1);

    char *last_hash = dup_pgtext(initial_hash_text); // this is last hash or initial if from first row
    const char *table_name = dup_pgtext(table_name_text); // table name to inspect

    openlog("hash_audit", LOG_NDELAY, LOG_SYSLOG);
    syslog(LOG_INFO, "Executed table '%s' full tampering detection", table_name);
    syslog(LOG_DEBUG, "input: %s,%s", last_hash, table_name);

    if(SPI_connect() == SPI_ERROR_CONNECT)
    {
		syslog(LOG_ERR, "Failed to load hash from \"%s\": SPI_connect() == SPI_ERROR_CONNECT", table_name);
		PG_RETURN_CSTRING(pstrdup(""));
	}

    /* Table examination part */
    static const char selectCountAllTemplate[] = "SELECT COUNT(*) AS ROW_COUNT FROM \"%s\";";
    static char queryCountAll[NAMEDATALEN + sizeof(selectCountAllTemplate)] = ""; // NAMEDATALEN is macro defined by postgre
    snprintf(queryCountAll, sizeof(queryCountAll), selectCountAllTemplate, table_name);

    int resultCountAll = SPI_execute(queryCountAll, true, 0);
    if(resultCountAll != SPI_OK_SELECT)
    {
		syslog(LOG_ERR, "Failed to load row count info from \"%s\": r != SPI_OK_SELECT", table_name);
		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
		PG_RETURN_CSTRING(pstrdup(""));
	}

    if(SPI_processed < 1)
    {
        SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
        syslog(LOG_ERR, "No row info found from  \"%s\"", table_name);
        PG_RETURN_CSTRING(pstrdup(""));
    }

    TupleDesc descCountAll = SPI_tuptable->tupdesc;
	HeapTuple rowCountAll = SPI_tuptable->vals[0];
    char *row_count_char = SPI_getvalue(rowCountAll, descCountAll, 1);
    int row_count = atoi(row_count_char);
    syslog(LOG_DEBUG, "Row count for table \"%s\" is %i", table_name, row_count);

    int block_count  = ceil(((double)row_count / limit_value));
    syslog(LOG_DEBUG, "Count of offsets blocks %i", block_count);

    // initialize sha256 context
    SHA256_CTX sha256;
    unsigned char hash[SHA256_DIGEST_LENGTH * 2 + 1];
    static char retHash[SHA256_DIGEST_LENGTH * 2 + 1] = "";

    int t;
    int offset_a = 0;
    // Whole table is selected on blocks defined by limit and offset_a
    // Iterativly for each
    for(t = 0; t < block_count; t++)
    {
        static const char prevHashQueryTemplate[] = "SELECT * FROM \"%s\" ORDER BY id ASC LIMIT %i OFFSET %i;";
        static char query[NAMEDATALEN + sizeof(prevHashQueryTemplate)] = ""; // NAMEDATALEN is macro defined by postgre
        snprintf(query, sizeof(query), prevHashQueryTemplate, table_name, limit_value, offset_a);
        syslog(LOG_DEBUG, "SELECT * FROM \"%s\" ORDER BY id ASC LIMIT %i OFFSET %i;", table_name, limit_value, offset_a);
        offset_a = offset_a + limit_value;

        // Execute query
        int result = SPI_execute(query, true, 0);
    	if(result != SPI_OK_SELECT)
        {
    		syslog(LOG_ERR, "Failed to load info from \"%s\": r != SPI_OK_SELECT", table_name);
    		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    		PG_RETURN_CSTRING(pstrdup(""));
    	}

    	if(SPI_processed < 1)
        {
    		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    		syslog(LOG_ERR, "No rows returned from  \"%s\"", table_name);
    		PG_RETURN_CSTRING(pstrdup(""));
    	}
        /* work on all rows returned from query*/

        int i;
        TupleDesc desc = SPI_tuptable->tupdesc;
        for(i = 0; i < SPI_processed; i++)
        {
            SHA256_Init(&sha256);
            HeapTuple row = SPI_tuptable->vals[i];

            char *id = SPI_getvalue(row, desc, 1);
            char *id_uuid = SPI_getvalue(row, desc, 2);
            char *history_id_uuid = SPI_getvalue(row, desc, 3);
            char *main_data = SPI_getvalue(row, desc, 4);
            char *file = SPI_getvalue(row, desc, 5);
            char *hashchain = SPI_getvalue(row, desc, 6);

            //syslog(LOG_INFO, "select:%s,%s,%s,%s,%s", id, id_uuid, history_id_uuid, main_data, hashchain);
            SHA256_Update(&sha256, last_hash, SHA256_DIGEST_LENGTH * 2);
            SHA256_Update(&sha256, id, strlen(id));
            SHA256_Update(&sha256, id_uuid, strlen(id_uuid));

            if ((history_id_uuid != NULL && history_id_uuid[0] != '\0'))
            {
                SHA256_Update(&sha256, history_id_uuid, strlen(history_id_uuid));
            }

            SHA256_Update(&sha256, main_data, strlen(main_data));
            SHA256_Update(&sha256, file, strlen(file));

            /* first 32 bytes of output will be binary representation of digest */
            SHA256_Final(hash, &sha256);
            /* convert binary representation to string */
            for(int i = SHA256_DIGEST_LENGTH - 1; i >= 0; i--)
            {
                hash[i * 2 + 1] = hexdigits[hash[i] & 0x0f];
                hash[i * 2] = hexdigits[(hash[i] & 0xf0) >> 4];
            }
            hash[SHA256_DIGEST_LENGTH * 2] = '\0'; // string terminator

            last_hash = hash; // hashchain vallue will be taken to last hash now
            SPI_freetuple(row);
        }
    }

    syslog(LOG_DEBUG, "freeing memory");
	SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    syslog(LOG_DEBUG, "returning");
    closelog();
    PG_RETURN_TEXT_P(cstring_to_text(last_hash));
}

/**
 * @returns varchar with calculated row hash
 * @note Postgre server takes care of freeing allocated memory
 * @note elog statements seem to have significant performance impact
 */
PG_FUNCTION_INFO_V1(getPartialTableHashFunction);
Datum getPartialTableHashFunction(PG_FUNCTION_ARGS)
{
    int id_first, id_last;
    text *initial_hash_text, *table_name_text;
    int limit_value = 100;

    id_first = PG_GETARG_INT32(0);
    id_last = PG_GETARG_INT32(1);
    initial_hash_text = PG_GETARG_TEXT_P(2);
    table_name_text = PG_GETARG_TEXT_P(3);

    char *last_hash = dup_pgtext(initial_hash_text); // this is last hash or initial if from first row
    const char *table_name = dup_pgtext(table_name_text); // table name to inspect

    openlog("hash_audit", LOG_NDELAY, LOG_SYSLOG);
    syslog(LOG_INFO, "Executed table '%s' partial tampering detection", table_name);
    syslog(LOG_DEBUG, "input:%i,%i,%s,%s", id_first, id_last, last_hash, table_name);

    if(SPI_connect() == SPI_ERROR_CONNECT)
    {
		syslog(LOG_ERR, "Failed to load hash from \"%s\": SPI_connect() == SPI_ERROR_CONNECT", table_name);
		PG_RETURN_CSTRING(pstrdup(""));
	}

    /* Table examination part */
    static const char selectCountAllTemplate[] = "SELECT COUNT(*) AS ROW_COUNT FROM \"%s\" WHERE id BETWEEN %i AND %i;";
    static char queryCountAll[NAMEDATALEN + sizeof(selectCountAllTemplate)] = ""; // NAMEDATALEN is macro defined by postgre
    snprintf(queryCountAll, sizeof(queryCountAll), selectCountAllTemplate, table_name, id_first, id_last);

    int resultCountAll = SPI_execute(queryCountAll, true, 0);
    if(resultCountAll != SPI_OK_SELECT)
    {
		syslog(LOG_ERR, "Failed to load row count info from \"%s\": r != SPI_OK_SELECT", table_name);
		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
		PG_RETURN_CSTRING(pstrdup(""));
	}

    if(SPI_processed < 1)
    {
        SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
        syslog(LOG_ERR, "No row info found from  \"%s\"", table_name);
        PG_RETURN_CSTRING(pstrdup(""));
    }

    TupleDesc descCountAll = SPI_tuptable->tupdesc;
	HeapTuple rowCountAll = SPI_tuptable->vals[0];
    char *row_count_char = SPI_getvalue(rowCountAll, descCountAll, 1);
    int row_count = atoi(row_count_char);
    syslog(LOG_DEBUG, "Row count for table \"%s\" is %i", table_name, row_count);

    int block_count  = ceil(((double)row_count / limit_value));
    syslog(LOG_DEBUG, "count of offsets blocks %i", block_count);

    // initialize sha256 context
    SHA256_CTX sha256;
    unsigned char hash[SHA256_DIGEST_LENGTH * 2 + 1];
    static char retHash[SHA256_DIGEST_LENGTH * 2 + 1] = "";

    int t;
    int offset_a = 0;
    // Whole table is selected on bloacks defined by limit and offset_a
    // Iterativly for each
    for(t = 0; t < block_count; t++)
    {
        static const char prevHashQueryTemplate[] = "SELECT * FROM \"%s\"  WHERE id BETWEEN %i AND %i ORDER BY id ASC LIMIT %i OFFSET %i;";
        static char query[NAMEDATALEN + sizeof(prevHashQueryTemplate)] = ""; // NAMEDATALEN is macro defined by postgre
        snprintf(query, sizeof(query), prevHashQueryTemplate, table_name, id_first, id_last, limit_value, offset_a);
        syslog(LOG_DEBUG, "SELECT * FROM \"%s\"  WHERE id BETWEEN %i AND %i ORDER BY id ASC LIMIT %i OFFSET %i;",
            table_name, id_first, id_last, limit_value, offset_a);
        offset_a = offset_a + limit_value;

        // Execute query
        int result = SPI_execute(query, true, 0);
    	if(result != SPI_OK_SELECT)
        {
    		syslog(LOG_ERR, "Failed to load info from \"%s\": r != SPI_OK_SELECT", table_name);
    		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    		PG_RETURN_CSTRING(pstrdup(""));
    	}

    	if(SPI_processed < 1)
        {
    		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    		syslog(LOG_ERR, "No rows returned from  \"%s\"", table_name);
    		PG_RETURN_CSTRING(pstrdup(""));
    	}
        /* work on all rows returned from query*/

        int i;
        TupleDesc desc = SPI_tuptable->tupdesc;
        for(i = 0; i < SPI_processed; i++)
        {
            SHA256_Init(&sha256);
            HeapTuple row = SPI_tuptable->vals[i];

            char *id = SPI_getvalue(row, desc, 1);
            char *id_uuid = SPI_getvalue(row, desc, 2);
            char *history_id_uuid = SPI_getvalue(row, desc, 3);
            char *main_data = SPI_getvalue(row, desc, 4);
            char *file = SPI_getvalue(row, desc, 5);
            char *hashchain = SPI_getvalue(row, desc, 6);

            SHA256_Update(&sha256, last_hash, SHA256_DIGEST_LENGTH * 2);
            SHA256_Update(&sha256, id, strlen(id));
            SHA256_Update(&sha256, id_uuid, strlen(id_uuid));

            if ((history_id_uuid != NULL && history_id_uuid[0] != '\0'))
            {
                SHA256_Update(&sha256, history_id_uuid, strlen(history_id_uuid));
            }

            SHA256_Update(&sha256, main_data, strlen(main_data));
            SHA256_Update(&sha256, file, strlen(file));

            /* first 32 bytes of output will be binary representation of digest */
            SHA256_Final(hash, &sha256);
            /* convert binary representation to string */
            for(int i = SHA256_DIGEST_LENGTH - 1; i >= 0; i--)
            {
                hash[i * 2 + 1] = hexdigits[hash[i] & 0x0f];
                hash[i * 2] = hexdigits[(hash[i] & 0xf0) >> 4];
            }
            hash[SHA256_DIGEST_LENGTH * 2] = '\0'; // string terminator

            last_hash = hash; // hashchain value will be taken to last hash now
        }
    }

    syslog(LOG_DEBUG, "freeing memory");
	SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    syslog(LOG_DEBUG, "returning");
    closelog();
    PG_RETURN_TEXT_P(cstring_to_text(last_hash));
}

/**
 * @returns varchar with calculated row hash
 * @note Postgre server takes care of freeing allocated memory
 * @note elog statements seem to have significant performance impact
 */
PG_FUNCTION_INFO_V1(getPartialTableHashFunctionWithErrorDetection);
Datum getPartialTableHashFunctionWithErrorDetection(PG_FUNCTION_ARGS)
{
    int id_first, id_last;
    text *initial_hash_text, *table_name_text;
    int limit_value = 100;

    id_first = PG_GETARG_INT32(0);
    id_last = PG_GETARG_INT32(1);
    initial_hash_text = PG_GETARG_TEXT_P(2);
    table_name_text = PG_GETARG_TEXT_P(3);

    char *last_hash = dup_pgtext(initial_hash_text); // this is last hash or initial if from first row
    char *error_hash = NULL, *error_id_uuid = NULL, *error_row_normal_hash, *result_string, *result_text;
    const char *table_name = dup_pgtext(table_name_text); // table name to inspect
    result_string = SPI_palloc((sizeof(char) * 300) + 1);

    openlog("hash_audit", LOG_NDELAY, LOG_SYSLOG);
    syslog(LOG_INFO, "Executed table '%s' partial tampering detection with error reporting", table_name);
    syslog(LOG_DEBUG, "input:%i,%i,%s,%s", id_first, id_last, last_hash, table_name);

    if(SPI_connect() == SPI_ERROR_CONNECT)
    {
		syslog(LOG_ERR, "Failed to load hash from \"%s\": SPI_connect() == SPI_ERROR_CONNECT", table_name);
		PG_RETURN_CSTRING(pstrdup(""));
	}

    /* Table examination part */
    static const char selectCountAllTemplate[] = "SELECT COUNT(*) AS ROW_COUNT FROM \"%s\" WHERE id BETWEEN %i AND %i;";
    static char queryCountAll[NAMEDATALEN + sizeof(selectCountAllTemplate)] = ""; // NAMEDATALEN is macro defined by postgre
    snprintf(queryCountAll, sizeof(queryCountAll), selectCountAllTemplate, table_name, id_first, id_last);

    int resultCountAll = SPI_execute(queryCountAll, true, 0);
    if(resultCountAll != SPI_OK_SELECT)
    {
		syslog(LOG_ERR, "Failed to load row count info from \"%s\": r != SPI_OK_SELECT", table_name);
		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
		PG_RETURN_CSTRING(pstrdup(""));
	}

    if(SPI_processed < 1)
    {
        SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
        syslog(LOG_ERR, "No row info found from  \"%s\"", table_name);
        PG_RETURN_CSTRING(pstrdup(""));
    }

    TupleDesc descCountAll = SPI_tuptable->tupdesc;
	HeapTuple rowCountAll = SPI_tuptable->vals[0];
    char *row_count_char = SPI_getvalue(rowCountAll, descCountAll, 1);
    int row_count = atoi(row_count_char);
    syslog(LOG_DEBUG, "Row count for table \"%s\" is %i", table_name, row_count);

    int block_count  = ceil(((double)row_count / limit_value));
    syslog(LOG_DEBUG, "count of offsets blocks %i", block_count);

    // initialize sha256 context
    SHA256_CTX sha256;
    unsigned char hash[SHA256_DIGEST_LENGTH * 2 + 1];
    static char retHash[SHA256_DIGEST_LENGTH * 2 + 1] = "";

    int t;
    int offset_a = 0;
    // Whole table is selected on bloacks defined by limit and offset_a
    // Iterativly for each
    for(t = 0; t < block_count; t++)
    {
        static const char prevHashQueryTemplate[] = "SELECT * FROM \"%s\"  WHERE id BETWEEN %i AND %i ORDER BY id ASC LIMIT %i OFFSET %i;";
        static char query[NAMEDATALEN + sizeof(prevHashQueryTemplate)] = ""; // NAMEDATALEN is macro defined by postgre
        snprintf(query, sizeof(query), prevHashQueryTemplate, table_name, id_first, id_last, limit_value, offset_a);
        syslog(LOG_DEBUG, "SELECT * FROM \"%s\"  WHERE id BETWEEN %i AND %i ORDER BY id ASC LIMIT %i OFFSET %i;",
            table_name, id_first, id_last, limit_value, offset_a);
        offset_a = offset_a + limit_value;

        // Execute query
        int result = SPI_execute(query, true, 0);
    	if(result != SPI_OK_SELECT)
        {
    		syslog(LOG_ERR, "Failed to load info from \"%s\": r != SPI_OK_SELECT", table_name);
    		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    		PG_RETURN_CSTRING(pstrdup(""));
    	}

    	if(SPI_processed < 1)
        {
    		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    		syslog(LOG_ERR, "No rows returned from  \"%s\"", table_name);
    		PG_RETURN_CSTRING(pstrdup(""));
    	}
        /* work on all rows returned from query*/

        int i;
        TupleDesc desc = SPI_tuptable->tupdesc;
        syslog(LOG_DEBUG, "Entering into second loop");
        for(i = 0; i < SPI_processed; i++)
        {
            SHA256_Init(&sha256);
            HeapTuple row = SPI_tuptable->vals[i];

            char *id = SPI_getvalue(row, desc, 1);
            char *id_uuid = SPI_getvalue(row, desc, 2);
            char *history_id_uuid = SPI_getvalue(row, desc, 3);
            char *main_data = SPI_getvalue(row, desc, 4);
            char *file = SPI_getvalue(row, desc, 5);
            char *hashchain = SPI_getvalue(row, desc, 6);

            SHA256_Update(&sha256, last_hash, SHA256_DIGEST_LENGTH * 2);
            SHA256_Update(&sha256, id, strlen(id));
            SHA256_Update(&sha256, id_uuid, strlen(id_uuid));
            if ((history_id_uuid != NULL && history_id_uuid[0] != '\0'))
            {
                SHA256_Update(&sha256, history_id_uuid, strlen(history_id_uuid));
            }
            SHA256_Update(&sha256, main_data, strlen(main_data));
            SHA256_Update(&sha256, file, strlen(file));

            /* first 32 bytes of output will be binary representation of digest */
            SHA256_Final(hash, &sha256);
            /* convert binary representation to string */
            for(int i = SHA256_DIGEST_LENGTH - 1; i >= 0; i--)
            {
                hash[i * 2 + 1] = hexdigits[hash[i] & 0x0f];
                hash[i * 2] = hexdigits[(hash[i] & 0xf0) >> 4];
            }
            hash[SHA256_DIGEST_LENGTH * 2] = '\0'; // string terminator

            if (strcmp(hash, hashchain) == 0){}
                // generated hash is equal with hash stored in database for this record
            else {
                syslog(LOG_DEBUG, "Not maching hashes generated | in database: %s != %s for record with uuid: %s" , hash, hashchain, id_uuid);
                error_hash = hash;
                error_id_uuid = id_uuid;
                error_row_normal_hash = hashchain;
                break;
            }
            last_hash = hash; // hashchain value will be taken to last hash now
        }
    }
    syslog(LOG_DEBUG, "hash link check completed, generating result message");
    if(error_id_uuid == NULL) {
        result_text = last_hash;
    } else {
        sprintf(result_string, "%s|%s|%s", error_id_uuid, error_hash, error_row_normal_hash);
        result_text = result_string;
    }
    syslog(LOG_DEBUG, "message %s", result_text);
    SPI_pfree(result_string);
	SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
    syslog(LOG_DEBUG, "returning");
    closelog();
    PG_RETURN_TEXT_P(cstring_to_text(result_text));
}
