#pragma once
#include <postgres.h>


#ifdef __cplusplus
extern "C" {
#endif

Datum getTableHashFunction(PG_FUNCTION_ARGS);
Datum getPartialTableHashFunction(PG_FUNCTION_ARGS);
Datum getPartialTableHashFunctionWithErrorDetection(PG_FUNCTION_ARGS);

#ifdef __cplusplus
}
#endif
