#include <string.h>
#include <syslog.h>
#include <openssl/sha.h>
#include <postgres.h>
#include <executor/spi.h>
#include <utils/rel.h>
#include <utils/builtins.h>
#include "hashchain.h"

static const char hexdigits[16] = "0123456789abcdef";
static const char hashchainFieldName[] = "hashchain";

/**
 * loads & returns hash of previous row in the relation
 * than once per table per server startup.
 * @param relationName name of relation/table
 * @returns hashchain value of last row of the relation
 * @note returned pointer points to statically allocated memory
 */
const char* loadHash(const char relationName[NAMEDATALEN])
{
	static const char prevHashQueryTemplate[] = "SELECT hashchain FROM \"%s\" ORDER BY id DESC LIMIT 1";
	static const char initialHash[] = "160488245c65a2f36685f107e1f499caac7f37dc6afb65a4ed9cc9f300b30f05";
	static char retHash[SHA256_DIGEST_LENGTH * 2 + 1] = "";
	static char query[NAMEDATALEN + sizeof(prevHashQueryTemplate)] = "";

	openlog("hash_chain", LOG_NDELAY, LOG_SYSLOG);
	syslog(LOG_DEBUG, "Trying to load hash from table \"%s\"", relationName);
	snprintf(query, sizeof(query), prevHashQueryTemplate, relationName);
	if(SPI_connect() == SPI_ERROR_CONNECT) {
		syslog(LOG_ERR, "Failed to load hash from \"%s\": SPI_connect() == SPI_ERROR_CONNECT", relationName);
		return NULL;
	}
	int r =	SPI_execute(query, true, 0);
	if(r != SPI_OK_SELECT) {
		syslog(LOG_ERR, "Failed to load hash from \"%s\": r != SPI_OK_SELECT", relationName);
		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
		return NULL;
	}
	if(SPI_processed != 1) {
		SPI_finish(); // ignore SPI_ERROR_UNCONNECTED error
		syslog(LOG_ERR, "No rows returned from  \"%s\", using initial hash: %s", relationName, initialHash);
		return initialHash;
	}
	HeapTuple row = SPI_tuptable->vals[0];
	TupleDesc desc = SPI_tuptable->tupdesc;
	char* hash = SPI_getvalue(row, desc, 1);
	memcpy(retHash, hash, SHA256_DIGEST_LENGTH * 2 + 1);
	pfree(hash);
	SPI_finish();
	syslog(LOG_DEBUG, "Hash loaded from \"%s\": %s", relationName, retHash);
	return retHash;
}

/**
 * @param rel relation (table)
 * @param row row to be inserted
 * @returns row with hashchain field filled
 * @note Postgre server takes care of freeing allocated memory
 * @note elog statements seem to have significant performance impact
 */
HeapTuple hashchain(const Relation rel, const HeapTuple row)
{
	const char* tableName = SPI_getrelname(rel); // table name
	int hashchainFieldNumber = SPI_fnumber(rel->rd_att, hashchainFieldName); // hashchain field index
	int idFieldNumber = SPI_fnumber(rel->rd_att, "id"); // id field index
	int idUuidFieldNumber = SPI_fnumber(rel->rd_att, "id_uuid"); // id_uuid index

	openlog("hash_chain", LOG_NDELAY, LOG_SYSLOG);

	if(hashchainFieldNumber <= 0) {
		elog(INFO, "hashchain triggered on table without hashchain field (%s)", tableName);
		return NULL; // not hashchain'ed, no-op
	}
	const char* prevHash = loadHash(tableName);
	if(prevHash == NULL) {
		elog(ERROR, "Couldn't get last hash (see system log)");
		return NULL;
	}

	/* initialize sha256 context */
	SHA256_CTX sha256;
	SHA256_Init(&sha256);
	SHA256_Update(&sha256, prevHash, SHA256_DIGEST_LENGTH * 2);

	/* add all fields to digest */
	int i;
	for(i = 1; i <= rel->rd_att->natts; i++)
    {
		if(i == hashchainFieldNumber) continue; // except hashchain field
		char* fieldValue = SPI_getvalue(row, rel->rd_att, i);
        if ((fieldValue != NULL && fieldValue[0] != '\0')) {
            SHA256_Update(&sha256, fieldValue, strlen(fieldValue));
        }
	}

	/* first 32 bytes of output will be binary representation of digest */
	unsigned char hash[SHA256_DIGEST_LENGTH * 2 + 1];
	SHA256_Final(hash, &sha256);

	/* convert binary representation to string */
	for(i = SHA256_DIGEST_LENGTH - 1; i >= 0; i--) {
		hash[i * 2 + 1] = hexdigits[hash[i] & 0x0f];
		hash[i * 2] = hexdigits[(hash[i] & 0xf0) >> 4];
	}
	hash[SHA256_DIGEST_LENGTH * 2] = '\0'; // string terminator

	/* send hash & metadata to log server */
	char* rowId = SPI_getvalue(row, rel->rd_att, idFieldNumber);
	char* rowUuid = SPI_getvalue(row, rel->rd_att, idUuidFieldNumber);
    syslog(LOG_NOTICE, "hashChainAudit:%s,%s,%s,%s,%s", tableName, rowId, rowUuid, prevHash, hash);

	/* create new tuple with hash field filled */
	int columns[1] = { hashchainFieldNumber };
	Datum values[1] = { CStringGetTextDatum(hash) };
	HeapTuple modifiedTuple = SPI_modifytuple(rel, row, 1, columns, values, NULL);

	if(SPI_result == SPI_ERROR_NOATTRIBUTE) {
		elog(ERROR, "SPI_result == SPI_ERROR_NOATTRIBUTE");
		return 0;
	}
	closelog();
	return modifiedTuple;
}
