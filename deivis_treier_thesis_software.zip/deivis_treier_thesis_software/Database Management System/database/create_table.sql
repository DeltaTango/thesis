--------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.getTableHashFunction(
    text,
    text)
  RETURNS character varying AS
'/usr/lib/postgresql/9.6/lib/hashchain.so', 'getTableHashFunction'
  LANGUAGE c VOLATILE STRICT
  COST 1;
ALTER FUNCTION public.getTableHashFunction(text, text)
  OWNER TO postgres;

-------------------------------

CREATE OR REPLACE FUNCTION public.getTableHashFunctionPublic(
    lasthash_i text,
    tablename_i text)
  RETURNS character varying AS
$BODY$
    DECLARE
        calculated_hash VARCHAR;
    BEGIN
        RAISE NOTICE '% %', lastHash_i, tableName_i;
        calculated_hash := getTableHashFunction(
                CAST(lastHash_i AS TEXT),
                CAST(tableName_i AS TEXT));
        RETURN calculated_hash;
    END; $BODY$
  LANGUAGE plpgsql VOLATILE
  COST 1;
ALTER FUNCTION public.getTableHashFunctionPublic(text, text)
  OWNER TO postgres;

--------------------------


CREATE OR REPLACE FUNCTION public.getPartialTableHashFunction(
    integer,
    integer,
    text,
    text)
  RETURNS character varying AS
'/usr/lib/postgresql/9.6/lib/hashchain.so', 'getPartialTableHashFunction'
  LANGUAGE c VOLATILE STRICT
  COST 1;
ALTER FUNCTION public.getPartialTableHashFunction(integer, integer, text, text)
  OWNER TO postgres;

  ------------------------------------------------

  CREATE OR REPLACE FUNCTION public.getPartialTableHashFunctionPublic(
      id_first integer,
      id_last integer,
      lasthash_i text,
      tablename_i text)
    RETURNS character varying AS
  $BODY$
      DECLARE
          calculated_hash VARCHAR;
      BEGIN
          RAISE NOTICE '% % % %', id_first, id_last, lastHash_i, tableName_i;
          calculated_hash := getPartialTableHashFunction(
                  id_first,
                  id_last,
                  CAST(lastHash_i AS TEXT),
                  CAST(tableName_i AS TEXT));
          RETURN calculated_hash;
      END; $BODY$
    LANGUAGE plpgsql VOLATILE
    COST 1;
  ALTER FUNCTION public.getPartialTableHashFunctionPublic(integer, integer, text, text)
    OWNER TO postgres;

    --------------------------


    CREATE OR REPLACE FUNCTION public.getPartialTableHashFunctionWithErrorDetection(
        integer,
        integer,
        text,
        text)
      RETURNS TEXT AS
    '/usr/lib/postgresql/9.6/lib/hashchain.so', 'getPartialTableHashFunctionWithErrorDetection'
      LANGUAGE c VOLATILE STRICT
      COST 1;
    ALTER FUNCTION public.getPartialTableHashFunctionWithErrorDetection(integer, integer, text, text)
      OWNER TO postgres;

      ------------------------------------------------

      CREATE OR REPLACE FUNCTION public.getPartialTableHashFunctionWithErrorDetectionPublic(
          id_first integer,
          id_last integer,
          lasthash_i text,
          tablename_i text)
        RETURNS TEXT AS
      $BODY$
          DECLARE
              result TEXT;
          BEGIN
              RAISE NOTICE '% % % %', id_first, id_last, lastHash_i, tableName_i;
              result := getPartialTableHashFunctionWithErrorDetection(
                      id_first,
                      id_last,
                      CAST(lastHash_i AS TEXT),
                      CAST(tableName_i AS TEXT));
              RETURN result;
          END; $BODY$
        LANGUAGE plpgsql VOLATILE
        COST 1;
      ALTER FUNCTION public.getPartialTableHashFunctionWithErrorDetectionPublic(integer, integer, text, text)
        OWNER TO postgres;

-- Function: public."hashchainTrigger"()

-- DROP FUNCTION public."hashchainTrigger"();

CREATE OR REPLACE FUNCTION public."hashchainTrigger"()
  RETURNS trigger AS
'/usr/lib/postgresql/9.6/lib/hashchain.so', 'hashchainTrigger'
  LANGUAGE c VOLATILE
  COST 1;
ALTER FUNCTION public."hashchainTrigger"()
  OWNER TO postgres;

-- Sequence: public.main_id_seq

-- DROP SEQUENCE public.main_id_seq;

CREATE SEQUENCE public.main_id_seq
  INCREMENT 1
  MINVALUE 1
  MAXVALUE 9223372036854775807
  START 1
  CACHE 1;
ALTER TABLE public.main_id_seq
  OWNER TO postgres;

-- Table: public.main_data

-- DROP TABLE public.main_data;

CREATE TABLE public.main_data
(
  id bigint NOT NULL DEFAULT nextval('main_id_seq'::regclass),
  id_uuid uuid NOT NULL DEFAULT uuid_generate_v4(),
  history_id_uuid uuid,
  main_data file,
  bdoc text,
  hashchain character varying(255),
  CONSTRAINT main_data_pkey PRIMARY KEY (id),
  CONSTRAINT main_data_id_key UNIQUE (id),
  CONSTRAINT main_data_id_uuid_key UNIQUE (id_uuid)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.main_data
  OWNER TO postgres;

-- Index: public.main_data_history_id_uuid_idx

-- DROP INDEX public.main_data_history_id_uuid_idx;

CREATE INDEX main_data_history_id_uuid_idx
  ON public.main_data
  USING btree
  (history_id_uuid);

-- Index: public.main_data_id_uuid_idx

-- DROP INDEX public.main_data_id_uuid_idx;

CREATE INDEX main_data_id_uuid_idx
  ON public.main_data
  USING btree
  (id_uuid);

-- Index: public.main_data_main_data_idx

-- DROP INDEX public.main_data_main_data_idx;

CREATE INDEX main_data_main_data_idx
  ON public.main_data
  USING gin
  (main_data);


-- Trigger: hashchaintrigger on public.main_data

-- DROP TRIGGER hashchaintrigger ON public.main_data;

CREATE TRIGGER hashchaintrigger
  BEFORE INSERT
  ON public.main_data
  FOR EACH ROW
  EXECUTE PROCEDURE public."hashchainTrigger"();
